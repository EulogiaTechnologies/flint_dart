import 'package:flint_dart/src/error/invalid_argument_exception.dart';

import '../error/database_exception.dart';
import '_connectors/_database_connection_factory.dart';
import '_connectors/_database_connection_proxy.dart';
import '_database_utils/_db_config.dart';
import 'monitoring/database_monitor.dart';
import 'power/database/_connectors/_database_connection.dart';

class ConnectionManager {
  static ConnectionManager? _singleton;
  final DatabaseMonitor _monitor = DatabaseMonitor();

  factory ConnectionManager() {
    _singleton ??= ConnectionManager._internal();
    return _singleton!;
  }

  ConnectionManager._internal();

  Map<String, DatabaseConnection> connectionMap = {};
  String? defaultConnection;

  bool get isConnected => connectionMap.isNotEmpty;

  DatabaseConnection? connection([String? connectionName]) {
    final name = connectionName ?? defaultConnection;
    return connectionMap[name];
  }

  Future<void> connect(DBConfig config, String connectionName) async {
    try {
      final connection = DatabaseConnectionFactory.createConnection(config);
      await connection.connect();

      final monitoredConnection = DatabaseConnectionProxy(
        connection,
        connectionName,
        _monitor,
      );
      connectionMap[connectionName] = monitoredConnection;
    } on InvalidArgumentError catch (e) {
      throw DatabaseErorr(
        "Failed to connect to the database",
        e,
      );
    }
  }

  Future<bool> transaction(
    Future<bool> Function() action, [
    String? connectionName,
  ]) async {
    final conn = connectionName ?? defaultConnection;
    if (conn == null) {
      throw DatabaseErorr("No connection specified for transaction");
    }

    DatabaseConnection? transactionConnection;

    transactionConnection = connection(connectionName);

    if (transactionConnection == null) {
      throw DatabaseErorr("Connection not found for transaction");
    }

    return await transactionConnection.transaction(action);
  }

  Stream<DatabaseAlert> get alerts => _monitor.alerts;
  Map<String, PerformanceStats> getPerformanceStats() =>
      _monitor.getPerformanceStats();
}
