enum DatabaseType {
  postgresql,
  mysql,
  sqlite,
}
