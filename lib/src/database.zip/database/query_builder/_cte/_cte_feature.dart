enum CteFeature {
  materialized,

  notMaterialized,

  recursive,
}
