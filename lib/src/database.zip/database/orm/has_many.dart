import 'package:flint_dart/src/database/power/orm/relation.dart';

class HasMany extends Relation {
  HasMany({
    required super.related,
    required super.parent,
    super.foreignKey,
    super.localKey,
  });
  @override
  List<Map<String, dynamic>> match(
    List<Map<String, dynamic>> models,
    List<Map<String, dynamic>> results,
    String relation,
  ) =>
      matchMany(
        models,
        results,
        relation,
        localKey,
        foreignKey ?? '${related.runtimeType.toString()}_id',
      );
}
