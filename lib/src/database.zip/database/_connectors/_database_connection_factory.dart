import 'package:flint_dart/src/error/invalid_argument_exception.dart';

import '../_database_utils/_db_config.dart';
import '../adapters/_mysql_connector.dart';
import '../adapters/_postgres_connector.dart';
import '../adapters/_sqlite_connector.dart';
import '../power/database/_connectors/_database_connection.dart';

class DatabaseConnectionFactory {
  static DatabaseConnection createConnection(DBConfig config) {
    return switch (config.driver) {
      'mysql' => MySqlConnector(config),
      'pgsql' => PostgresConnector(config),
      'sqlite' => SQLiteConnector(config),
      _ => throw InvalidArgumentError(
          "Unsupported driver [${config.driver}].",
        ),
    };
  }
}
